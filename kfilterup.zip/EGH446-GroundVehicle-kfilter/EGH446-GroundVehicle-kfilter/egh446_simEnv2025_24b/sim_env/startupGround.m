%% startupGround.m — run model, compute & plot cross-track RMSE
% Closes any open model, generates waypoints, runs the sim, extracts x–y,
% computes RMSE to the waypoint path, and plots results.

%% Housekeeping
close_system('sl_groundvehicleDynamics23b',0);
clear all; clc; close all;

rng(3);  % reproducible random waypoints

%% Generate & order waypoints
unordered_waypoints.x = randi([-500 500],1,10);
unordered_waypoints.y = randi([-500 500],1,10);

[waypoints.x, waypoints.y] = order_waypoints(unordered_waypoints.x, unordered_waypoints.y);

% Make waypoints visible to the model (if blocks read from base workspace)
assignin('base','waypoints',waypoints);

%% Add toolboxes to path (optional)
homedir = pwd;
addpath( genpath(fullfile(homedir,'toolboxes')) );

tbxStarter = fullfile(homedir,'toolboxes','MRTB','startMobileRoboticsSimulationToolbox.m');
if exist(tbxStarter,'file')
    try, run(tbxStarter); end %#ok<RUN>
end

%% Run model (let model StopTime control the run)
open('sl_groundvehicleDynamics23b.slx' ...
    )
set_param('sl_groundvehicleDynamics23b','ReturnWorkspaceOutputs','on'); % ensure simOut returns
simOut = sim('sl_groundvehicleDynamics23b.slx');

%% Extract pose (expects To Workspace blocks named 'x' and 'y' in Timeseries format)
x_ts  = simOut.x;           % timeseries
y_ts  = simOut.y;           % timeseries
time  = x_ts.Time(:);
x_pos = x_ts.Data(:);
y_pos = y_ts.Data(:);

%% Waypoints as row vectors
waypoints_x = waypoints.x(:).';
waypoints_y = waypoints.y(:).';

%% Compute RMSE + per-sample cross-track error (CTE)
[rmse_cross_track, cte] = calculateCrossTrackRMSE(x_pos, y_pos, waypoints_x, waypoints_y);
fprintf('Cross-track RMSE: %.3f m (N=%d samples)\n', rmse_cross_track, numel(cte));

%% Ensure time aligns with CTE length
n = min(numel(time), numel(cte));
t = time(1:n);
cte = cte(1:n);

%% Plots
% 1) Path vs waypoints
figure('Name','Path vs Waypoints');
plot(waypoints_x, waypoints_y, 'o-','DisplayName','Waypoints'); hold on;
plot(x_pos, y_pos, '.-','DisplayName','Vehicle path');
axis equal; grid on; legend('Location','best');
title(sprintf('Path vs Waypoints (RMSE = %.3f m)', rmse_cross_track));
xlabel('X (m)'); ylabel('Y (m)');

% 2) CTE over time
figure('Name','Cross-track error vs time');
plot(t, cte, 'LineWidth', 1.3);
grid on; xlabel('Time (s)'); ylabel('Cross-track error (m)');
title(sprintf('CTE over time (RMSE = %.3f m)', rmse_cross_track));

% 3) Cumulative RMSE vs time (converges to final RMSE)
cumRMSE = sqrt(cumsum(cte.^2) ./ (1:n)');
figure('Name','Cumulative RMSE vs time');
plot(t, cumRMSE, 'LineWidth', 1.3);
grid on; xlabel('Time (s)'); ylabel('Cumulative RMSE (m)');
title('Cumulative RMSE vs time');

% 4) Sliding-window RMSE (local performance)
if n > 1
    dt = median(diff(t));
    winSec = 5;                          % adjust as desired
    winN   = max(1, round(winSec/dt));
    swRMSE = sqrt(movmean(cte.^2, winN));

    figure('Name','Sliding-window RMSE');
    plot(t, swRMSE, 'LineWidth', 1.3);
    grid on; xlabel('Time (s)'); ylabel(sprintf('RMSE over %.1f s window (m)', winSec));
    title('Sliding-window RMSE');
end

%% ===================== Local functions =====================

function [ordered_wp_x, ordered_wp_y] = order_waypoints(wp_x, wp_y)
    % Nearest-neighbour + 2-opt ordering of waypoints
    waypoints = [wp_x(:), wp_y(:)];
    num_waypoints = size(waypoints, 1);

    waypoint_idx = 1:num_waypoints;
    route = zeros(1, num_waypoints);

    route(1) = 1;
    waypoint_idx(1) = [];

    % Nearest neighbour
    for i = 1:num_waypoints-1
        current_waypoint = waypoints(route(i), :);
        distances = zeros(1, length(waypoint_idx));
        for j = 1:length(waypoint_idx)
            next_potential_point = waypoints(waypoint_idx(j), :);
            distances(j) = pdist2(current_waypoint, next_potential_point);
        end
        [~, min_idx] = min(distances);
        route(i+1) = waypoint_idx(min_idx);
        waypoint_idx(min_idx) = [];
    end

    % 2-opt swap
    improved = true;
    tolerance = 1e-12;
    get_dist = @(a,b) pdist2(waypoints(a, :), waypoints(b, :));

    while improved
        improved = false;
        for i = 1:num_waypoints-3
            a = route(i); b = route(i+1);
            for j = i+2:num_waypoints-1
                c = route(j); d = route(j+1);
                delta = (get_dist(a,c) + get_dist(b,d)) - (get_dist(a,b) + get_dist(c,d));
                if delta < -tolerance
                    route(i+1:j) = route(j:-1:i+1);
                    improved = true;
                end
            end
        end
    end

    ordered_wp_x = waypoints(route, 1);
    ordered_wp_y = waypoints(route, 2);
end

function [rmse, cte] = calculateCrossTrackRMSE(vehicle_x, vehicle_y, waypoints_x, waypoints_y)
% calculateCrossTrackRMSE
%   rmse : scalar RMSE of cross-track error (meters)
%   cte  : Nx1 vector of per-sample cross-track errors (meters)

    vx = vehicle_x(:);
    vy = vehicle_y(:);
    wx = waypoints_x(:);
    wy = waypoints_y(:);

    if numel(wx) < 2
        error('Waypoints must contain at least two points.');
    end

    % Precompute segment endpoints & lengths
    x1 = wx(1:end-1); y1 = wy(1:end-1);
    x2 = wx(2:end);   y2 = wy(2:end);
    dx = x2 - x1;     dy = y2 - y1;
    L2 = dx.^2 + dy.^2;                % (M x 1)

    n  = numel(vx);
    cte = zeros(n,1);

    for k = 1:n
        px = vx(k); py = vy(k);

        % Projection parameter t for each segment
        t = ((px - x1).*dx + (py - y1).*dy) ./ max(L2, eps);
        t = max(0, min(1, t));         % clamp to [0,1]

        % Closest points on each segment
        cx = x1 + t.*dx;
        cy = y1 + t.*dy;

        % Squared distances to each segment
        d2 = (px - cx).^2 + (py - cy).^2;

        % Min distance is the cross-track error
        cte(k) = sqrt(min(d2));
    end

    rmse = sqrt(mean(cte.^2));
end
